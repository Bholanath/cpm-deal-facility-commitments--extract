package cpm.deal.facility.commitments;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CpmDealFacilityCommitmentsExtractApplicationTests {

	@Test
	void contextLoads() {
	}

}
